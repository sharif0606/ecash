<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateBillsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('bills', function (Blueprint $table) {
            $table->id();
			$table->integer('company_id');
			$table->integer('sl_no');
			$table->date('bill_date');
			$table->string('business_name')->nullable();
			$table->string('business_add',1000)->nullable();
			$table->string('contact_person')->nullable();
			$table->string('contact_no_a')->nullable();
			$table->string('contact_no_b')->nullable();
			$table->string('email')->nullable();
			$table->string('website')->nullable();
			$table->string('cash')->nullable();
			$table->string('amount_in_word')->nullable();
			$table->unsignedFloat('due', 10, 2)->default(0);
			$table->unsignedFloat('discount', 10, 2)->default(0);
			$table->unsignedFloat('tax', 10, 2)->default(0);
			$table->unsignedFloat('total_amount', 10, 2)->default(0);
			$table->string('cheque_no')->nullable();
			$table->string('bank_name')->nullable();
			$table->date('cheque_date')->nullable();
			$table->string('cancel_reason',500)->nullable();
			$table->boolean('status')->default(1)->comment('0 => Inactive, 1 => Active' );
			$table->unsignedBigInteger('companyId');
            $table->unsignedBigInteger('userId');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('bills');
    }
}
