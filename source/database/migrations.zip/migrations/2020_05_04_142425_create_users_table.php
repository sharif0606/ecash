<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Carbon\Carbon;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('name', 50);
            $table->string('username', 50)->unique();
            $table->string('email', 100)->unique();
            $table->string('mobileNumber', 20)->unique();
            $table->string('timezone')->nullable();
            $table->string('password', 32);
            $table->boolean('status', 1)->default(1)->comment('0 => inactive, 1 => active, 2 => pending, 3 => freez, 4 => block' );
            $table->unsignedTinyInteger('roleId');
            $table->unsignedInteger('userCreatorId')->nullable();
            $table->unsignedInteger('adminId')->nullable()->comment('use for Executive' );
            $table->unsignedInteger('executiveId')->nullable()->comment('use for Account Manager and Marketing Manager' );
            $table->unsignedInteger('marketingmanagerId')->nullable()->comment('use for Owner' );
            $table->unsignedBigInteger('companyId')->nullable();
            $table->foreign('roleId')->references('id')->on('roles')->onDelete('cascade');
            $table->index(['companyId']);
            $table->index(['name']);
            $table->index(['username']);
            $table->index(['email']);
            $table->index(['mobileNumber']);
            $table->timestamps();
        });

        DB::table('users')->insert([
            [
                'name' => 'Superadmin',
                'username' => 'superadmin',
                'email' => 'superadmin@gmail.com',
                'mobileNumber' => '123456789',
                'password' => md5('superadmin'),
                'status' => 1,
                'roleId' => 1,
                'userCreatorId' => 1,
                'adminId' => null,
                'executiveId' => null,
                'marketingmanagerId' => null,
                'companyId' => null,
                'created_at' => Carbon::now()
            ],
			[
                'name' => 'Admin',
                'username' => 'admin',
                'email' => 'admin@gmail.com',
                'mobileNumber' => '123456788',
                'password' => md5('admin'),
                'status' => 1,
                'roleId' => 2,
                'userCreatorId' => 1,
                'adminId' => null,
                'executiveId' => null,
                'marketingmanagerId' => null,
                'companyId' => null,
                'created_at' => Carbon::now()
            ],
			[
                'name' => 'Data Entry',
                'username' => 'dataentry',
                'email' => 'dataentry@gmail.com',
                'mobileNumber' => '123456787',
                'password' => md5('dataentry'),
                'status' => 1,
                'roleId' => 3,
                'userCreatorId' => 1,
                'adminId' => null,
                'executiveId' => null,
                'marketingmanagerId' => null,
                'companyId' => null,
                'created_at' => Carbon::now()
            ],
            [
                'name' => 'Executive',
                'username' => 'executive',
                'email' => 'executive@gmail.com',
                'mobileNumber' => '123456786',
                'password' => md5('executive'),
                'status' => 1,
                'roleId' => 4,
                'userCreatorId' => 2,
                'adminId' => 2,
                'executiveId' => null,
                'marketingmanagerId' => null,
                'companyId' => null,
                'created_at' => Carbon::now()
            ],
            [
                'name' => 'Account Manager',
                'username' => 'accountmanager',
                'email' => 'accountmanager@gmail.com',
                'mobileNumber' => '123456785',
                'password' => md5('accountmanager'),
                'status' => 1,
                'roleId' => 5,
                'userCreatorId' => 4,
                'adminId' => null,
                'executiveId' => 4,
                'marketingmanagerId' => null,
                'companyId' => null,
                'created_at' => Carbon::now()
            ],
            [
                'name' => 'Marketing Manager',
                'username' => 'marketingmanager',
                'email' => 'marketingmanager@gmail.com',
                'mobileNumber' => '123456784',
                'password' => md5('marketingmanager'),
                'status' => 1,
                'roleId' => 6,
                'userCreatorId' => 4,
                'adminId' => null,
                'executiveId' => 4,
                'marketingmanagerId' => null,
                'companyId' => null,
                'created_at' => Carbon::now()
            ],
            [
                'name' => 'owner',
                'username' => 'owner',
                'email' => 'owner@gmail.com',
                'mobileNumber' => '123456783',
                'password' => md5('owner'),
                'status' => 1,
                'roleId' => 7,
                'userCreatorId' => 6,
                'adminId' => null,
                'executiveId' => null,
                'marketingmanagerId' => 6,
                'companyId' => 1,
                'created_at' => Carbon::now()
            ],
            [
                'name' => 'Sales Manager',
                'username' => 'salesmanager',
                'email' => 'salesmanager@gmail.com',
                'mobileNumber' => '123456782',
                'password' => md5('salesmanager'),
                'status' => 1,
                'roleId' => 8,
                'userCreatorId' => 7,
                'adminId' => null,
                'executiveId' => null,
                'marketingmanagerId' => null,
                'companyId' => 1,
                'created_at' => Carbon::now()
            ],
            [
                'name' => 'Sales Man',
                'username' => 'salesman',
                'email' => 'salesman@gmail.com',
                'mobileNumber' => '123456781',
                'password' => md5('salesman'),
                'status' => 1,
                'roleId' => 9,
                'userCreatorId' => 7,
                'adminId' => null,
                'executiveId' => null,
                'marketingmanagerId' => null,
                'companyId' => 1,
                'created_at' => Carbon::now()
            ]
        ]);
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
