<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateProductsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('products', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('sku');
            $table->string('thumbnail', 30)->nullable();
            $table->unsignedInteger('brandId');
            $table->foreign('brandId')->references('id')->on('brands')->onDelete('cascade');
            $table->string('brandName', 100);
            $table->string('genericName', 255);
            $table->string('strength', 255);
            $table->string('shortDescription', 500)->nullable();
            $table->unsignedFloat('mrpPrice', 8,2)->default(0);
            $table->unsignedInteger('discount')->nullable()->default(0);
            $table->boolean('discountStatus')->default(0)->comment('0=> No Discount 1 => Percentis Discount, 2 => Fixed Discount' );
            $table->boolean('status')->default(1)->comment('0 => Inactive, 1 => Active' );
            $table->string('tag')->nullable();
            $table->unsignedBigInteger('userId');
            $table->unsignedTinyInteger('dosageDescriptionId');
            $table->foreign('dosageDescriptionId')->references('id')->on('dose_descriptions')->onDelete('cascade');
            $table->unsignedTinyInteger('categoryId');
            $table->foreign('categoryId')->references('id')->on('categories')->onDelete('cascade');
            $table->unsignedBigInteger('companyId')->nullable();
            $table->index('sku');
            $table->index('brandName');
            $table->index('mrpPrice');
            $table->index('tag');
            $table->index('userId');
            $table->index('categoryId');
            $table->index('brandId');
            $table->index('dosageDescriptionId');
            $table->index('companyId');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('products');
    }
}
